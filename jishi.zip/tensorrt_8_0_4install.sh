用tensorrt加速推理时没有结果，原因是将输入数据转化成fp16了，只要不转化数据成fp16还是保存fp32即可，或者在输入数据进入模型前print('before pred img',img)也可以，具体原因我也不知道。

# 安装cuda10.2 by runfile,注意如果有driver,要设置不安装driver,否则会出错
wget https://developer.download.nvidia.com/compute/cuda/10.2/Prod/local_installers/cuda_10.2.89_440.33.01_linux.run
sudo sh cuda_10.2.89_440.33.01_linux.run
echo export PATH=$PATH:/usr/local/cudasource ~/.zshrc-10.2/bin >> ~/.zshrc
echo export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda-10.2/lib64 >> ~/.zshrc
source ~/.zshrc

# 安装cudnn8.3.2 by tar
wget https://minio.cvmart.net/user-file/25030/208877b0d65d463a8e18b524c7f7f454.xz
mv 208877b0d65d463a8e18b524c7f7f454.xz cudnn-linux-x86_64-8.3.2.44_cuda10.2-archive.tar.xz
tar -xvf cudnn-linux-x86_64-8.3.2.44_cuda10.2-archive.tar.xz
sudo cp cudnn-linux-x86_64-8.3.2.44_cuda10.2-archive/include/cudnn*.h /usr/local/cuda-10.2/include/ 
sudo cp cudnn-linux-x86_64-8.3.2.44_cuda10.2-archive/lib/libcudnn* /usr/local/cuda-10.2/lib64/
sudo chmod a+r /usr/local/cuda-10.2/include/cudnn*.h /usr/local/cuda-10.2/lib64/libcudnn*

# 安装tensorrt-8.4.0.6 by tar
wget https://minio.cvmart.net/user-file/25030/84c5b96d884846359b63b52bfa9c7031.gz
mv 84c5b96d884846359b63b52bfa9c7031.gz TensorRT-8.4.0.6.Linux.x86_64-gnu.cuda-10.2.cudnn8.3.tar.gz
tar -xzvf 
echo "export LD_LIBRARY_PATH=/project/train/src_repo/TensorRT-7.0.0.11/lib:/project/train/src_repo/TensorRT-7.0.0.11/targets/x86_64-linux-gnu/lib:$LD_LIBRARY_PATH"  >> ~/.zshrc
source ~/.zshrc
cd TensorRT-8.4.0.6/python 
pip install tensorrt-8.4.0.6-cp36-none-linux_x86_64.whl
# 如果要使用tensorflow的话
cd ../../TensorRT-8.4.0.6/uff 
pip install uff-0.6.9-py2.py3-none-any.whl
cd ../graphsurgeon 
pip install graphsurgeon-0.4.5-py2.py3-none-any.whl
cd ../onnx_graphsurgeon 
pip install onnx_graphsurgeon-0.3.12-py2.py3-none-any.whl

# 安装opencv4.5.5 by source code
wget https://github.com/opencv/opencv/archive/4.5.5.zip
unzip 4.5.5.zip
cd opencv-4.5.5
mkdir build && cd build
cmake ..
make -j8
sudo make install

# 验证tensorrt安装成功
python
import tensorrt
print(tensorrt.__version__)